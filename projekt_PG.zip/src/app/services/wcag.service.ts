import { Injectable } from '@angular/core';

@Injectable()
export class WcagService {
  public darkMode: any;
  public bigFont: any;
  constructor() { }
}
