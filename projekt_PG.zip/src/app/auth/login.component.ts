import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms'
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'login',
  templateUrl: './login.components.html',
  styleUrls: ['./login.components.css']
})
export class LoginComponent implements OnInit {

  loginForm = this.fb.group({
    username:[''],
    password:['']
  })
  message: string;

  constructor(private fb:FormBuilder,
            private auth:AuthService,
            private router:Router) { }

  login(){
    this.auth.login(this.loginForm.value);
     this.router.navigate(["/searchflight"])
  }

  ngOnInit() {
    this.message = this.auth.getMessage()
  }

}
