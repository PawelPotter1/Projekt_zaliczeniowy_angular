
export const users = [
    {"id":1,"login":"test1","password":"haslo1"},
    {"id":2,"login":"test2","password":"haslo2"},
    {"id":3,"login":"test3","password":"p@ssw0rd3"},
    {"id":4,"login":"test4","password":"p@ssw0rd4"},
    {"id":5,"login":"test5","password":"p@ssw0rd5"},
    {"id":6,"login":"test6","password":"p@ssw0rd6"},
    {"id":7,"login":"test7","password":"p@ssw0rd7"},
    {"id":8,"login":"test8","password":"p@ssw0rd8"}
]