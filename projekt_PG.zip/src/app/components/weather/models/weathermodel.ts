export class Weathermodel {
    city: String
    conditions: String
    temperature: number
    icon: String
  }