export class flightDetailsModel {
  departurePlace: string
  arrivalPlace: string
  departureDate: number
  arrivalDate: number
  persons: number
  senior: boolean
  kid: boolean
  bagage: string
  price: number
  }